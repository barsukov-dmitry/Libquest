create procedure book_order()
  BEGIN

INSERT INTO taken (T_id, deadline, Read_id, Rechall_id)
VALUES (5,2018-09-09 , 2, 10);

END;

