create procedure rechall_update(IN cur_del_id int)
  BEGIN

DECLARE cur_copies_cost FLOAT DEFAULT 0;
DECLARE cur_copies_number INTEGER DEFAULT 0;
DECLARE cur_book_id INTEGER DEFAULT 0;
DECLARE done INTEGER DEFAULT 0;

DECLARE C1 CURSOR FOR
SELECT Book_id, Copies_number, Copy_price
FROM `list` 
WHERE Del_id = cur_del_id;

DECLARE EXIT HANDLER FOR SQLSTATE '02000'
SET done = 1;

SELECT Updating INTO done
FROM `delivery`
WHERE Del_id = cur_del_id;

UPDATE delivery SET Updating = 1
WHERE Del_id = cur_del_id;

OPEN C1;

WHILE done = 0 DO
FETCH C1 INTO cur_book_id, cur_copies_number, cur_copies_cost;
UPDATE rechall SET Same_id_number = Same_id_number + cur_copies_number
WHERE Books_id = cur_book_id;
UPDATE rechall SET Same_id_cost = Same_id_cost + cur_copies_cost * cur_copies_number
WHERE Books_id = cur_book_id;
END WHILE;

CLOSE C1;

END;

